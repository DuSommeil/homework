#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "inputdialog.h"
#include "resultdialog.h"
#include <cmath>
#include <QMessageBox>
#include <QApplication>  // Для qApp->quit()

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow),
      a(0), b(0), c(0), calcPerimeter(false), calcArea(false)
{
    ui->setupUi(this); // Загружаем UI (кнопки, поля и т.д.)

    // Привязываем кнопки к методам
    connect(ui->btnInput, &QPushButton::clicked, this, &MainWindow::showInputDialog);
    connect(ui->btnCalc, &QPushButton::clicked, this, &MainWindow::calculate);
    connect(ui->btnExit, &QPushButton::clicked, this, &MainWindow::exitApp);
}

// Деструктор
MainWindow::~MainWindow()
{
    delete ui;
}

//Показываем диалог ввода
void MainWindow::showInputDialog()
{
    InputDialog dialog(this); // создаём окно InputDialog
    if (dialog.exec() == QDialog::Accepted) // если нажали ок
    {
        a = dialog.getA();
        b = dialog.getB();
        c = dialog.getC();
        calcPerimeter = dialog.isPerimeterChecked(); // маркер/флаг
        calcArea = dialog.isAreaChecked(); // маркер/флаг
    }
}

// Расчет и вывод результатов
void MainWindow::calculate()
{
    // Если не выбрано ничего
    if (!calcPerimeter && !calcArea)
    {
        QMessageBox::warning(this, "Ошибка", "Выберите хотя бы один режим (периметр или площадь)");
        return;
    }

    // Проверка на корректность треугольника
    if (a <= 0 || b <= 0 || c <= 0 ||
        (a + b <= c) || (a + c <= b) || (b + c <= a))
    {
        QMessageBox::warning(this, "Ошибка", "Введите корректные длины сторон треугольника.");
        return;
    }

    ResultDialog dlg(this); // создаём окно результата

    // Если выбрано - рассчитываем периметр
    if (calcPerimeter)
    {
        double perimeter = a + b + c;
        dlg.setPerimeter(perimeter);
    }

    // Если выбрано - рассчитываем площадь по формуле Герона
    if (calcArea)
    {
        double s = (a + b + c) / 2.0;
        double area = sqrt(s * (s - a) * (s - b) * (s - c));
        dlg.setArea(area);
    }

    dlg.exec(); // показываем окно с результатами
}


void MainWindow::exitApp()
{
    qApp->quit();
}
