#include "inputdialog.h"
#include "ui_inputdialog.h"

InputDialog::InputDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::InputDialog)
{
    ui->setupUi(this);

    // Подключаем сигналы кнопок Ok и Cancel
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(ui->buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
}

InputDialog::~InputDialog()
{
    delete ui;
}

// Получение значений сторон
double InputDialog::getA() const
{
    return ui->lineEditA->text().toDouble();
}

double InputDialog::getB() const
{
    return ui->lineEditB->text().toDouble();
}

double InputDialog::getC() const
{
    return ui->lineEditC->text().toDouble();
}

// Проверка, выбраны ли флаги
bool InputDialog::isPerimeterChecked() const
{
    return ui->checkPerimeter->isChecked();
}

bool InputDialog::isAreaChecked() const
{
    return ui->checkArea->isChecked();
}
