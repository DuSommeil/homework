#ifndef RESULTDIALOG_H
#define RESULTDIALOG_H

#include <QDialog>

namespace Ui {class ResultDialog;}

class ResultDialog : public QDialog
{

public:
    explicit ResultDialog(QWidget *parent = nullptr); // Конструктор
    ~ResultDialog(); // Деструктор

    // Установка текста в QLabel
    void setPerimeter(double perimeter);
    void setArea(double area);

private:
    Ui::ResultDialog *ui;
};

#endif // RESULTDIALOG_H
