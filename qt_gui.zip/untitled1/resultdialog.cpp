#include "resultdialog.h"
#include "ui_resultdialog.h"

ResultDialog::ResultDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ResultDialog)
{
    ui->setupUi(this);

    // Подключаем кнопки OK и Cancel
    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(ui->buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
}

ResultDialog::~ResultDialog()
{
    delete ui;
}

void ResultDialog::setPerimeter(double perimeter)
{
    QString text = QString("Периметр: %1").arg(perimeter, 0, 'f', 2);
    ui->labelPerimeter->setText(text);
}

void ResultDialog::setArea(double area)
{
    QString text = QString("Площадь: %1").arg(area, 0, 'f', 2);
    ui->labelArea->setText(text);
}
