#ifndef INPUTDIALOG_H
#define INPUTDIALOG_H

#include <QDialog>

namespace Ui {class InputDialog;}

class InputDialog : public QDialog
{

public:
    explicit InputDialog(QWidget *parent = nullptr); // Конструктор
    ~InputDialog(); // Деструктор

    // Геттеры сторон
    double getA() const;
    double getB() const;
    double getC() const;
    // Проверка выбранных чекбоксов
    bool isPerimeterChecked() const;
    bool isAreaChecked() const;

private:
    Ui::InputDialog *ui; // Интерфейс формы
};

#endif // INPUTDIALOG_H
